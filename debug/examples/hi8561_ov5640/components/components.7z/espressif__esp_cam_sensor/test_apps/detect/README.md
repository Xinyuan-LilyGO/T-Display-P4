| Supported Targets | ESP32-P4 |
| ----------------- | ----- |

# ESP SCCB COMPONENT

This component provides an interface for SCCB (Serial Camera Control Bus) and its implementations.

[![Component Registry](https://components.espressif.com/components/espressif/esp_sccb_intf/badge.svg)](https://components.espressif.com/components/espressif/esp_sccb_intf)

Now we have implementations based on:

- esp-driver-i2c
